# Qtc-web
Web dashboard for QuantumChain (QTC)

## Setup

```bash
npm install
cp .env.local.example .env.local   # fill in real values
npm run dev
```

Required env vars (`.env.local`):
- `NEXTAUTH_URL` — e.g. `http://localhost:3000`
- `NEXTAUTH_SECRET` — generate with `openssl rand -hex 32`
- `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET` — from a GitHub OAuth App
  (callback URL: `http://localhost:3000/api/auth/callback/github`)
- `NEXT_PUBLIC_RPC_URL` — your qc-node JSON-RPC endpoint (default `http://localhost:8545`)

## What's implemented
- Landing page: hero, features, tokenomics (placeholder numbers), footer.
- GitHub OAuth login (NextAuth v5) with a `SessionProvider` wrapping the app.
- Dashboard: link a validator address (stored in browser localStorage), see
  live block height and QTC balance via `eth_blockNumber` / `eth_getBalance`.
- Leaderboard page and API route.

## What's stubbed, pending qc-node support
Blocks proposed, uptime, rewards, network-wide stats, and the leaderboard
all call placeholder RPC methods (`qtc_getValidator`, `qtc_getNetworkStats`,
`qtc_getValidators`) that don't exist on qc-node yet. The frontend falls
back to zeros/empty state gracefully — once those methods are added to the
node, the UI will pick them up with no frontend changes needed.

## Not yet built
- Persistent validator profiles / GitHub-to-address linking server-side
  (currently client-only via localStorage — add Supabase or Prisma if you
  want this to survive across devices).
- Staking/vesting UI, governance viewer, faucet, explorer.
