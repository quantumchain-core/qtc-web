"use client";

import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";

type Stats = {
  blockNumber: number;
  balance: number;
  blocksProposed: number;
  uptime: number;
  rewards: number;
  live: boolean;
};

const ADDRESS_KEY = "qtc_validator_address";

export default function Dashboard() {
  const { data: session } = useSession();
  const [address, setAddress] = useState("");
  const [addressInput, setAddressInput] = useState("");
  const [stats, setStats] = useState<Stats>({
    blockNumber: 0,
    balance: 0,
    blocksProposed: 0,
    uptime: 0,
    rewards: 0,
    live: false,
  });
  const [loading, setLoading] = useState(true);

  // Load a previously linked address from localStorage on mount.
  useEffect(() => {
    const saved = localStorage.getItem(ADDRESS_KEY);
    if (saved) setAddress(saved);
  }, []);

  const fetchStats = async (addr: string) => {
    setLoading(true);
    try {
      const [blockRes, balanceRes, validatorRes] = await Promise.all([
        fetch("/api/block").then((r) => r.json()),
        addr
          ? fetch(`/api/balance?address=${addr}`).then((r) => r.json())
          : Promise.resolve({ balance: 0 }),
        addr
          ? fetch(`/api/validator?address=${addr}`).then((r) => r.json())
          : Promise.resolve({ blocksProposed: 0, uptime: 0, rewards: 0, live: false }),
      ]);
      setStats({
        blockNumber: blockRes.blockNumber ?? 0,
        balance: balanceRes.balance ?? 0,
        blocksProposed: validatorRes.blocksProposed ?? 0,
        uptime: validatorRes.uptime ?? 0,
        rewards: validatorRes.rewards ?? 0,
        live: validatorRes.live ?? false,
      });
    } catch {
      // keep last known stats on error
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchStats(address);
    const interval = setInterval(() => fetchStats(address), 5000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address]);

  const linkAddress = () => {
    const trimmed = addressInput.trim();
    if (!trimmed) return;
    localStorage.setItem(ADDRESS_KEY, trimmed);
    setAddress(trimmed);
    setAddressInput("");
  };

  if (!session) {
    return <div className="text-center pt-32">Please login with GitHub</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <h1 className="text-5xl font-bold mb-2">Validator Dashboard</h1>
      <p className="text-gray-400 mb-10">Welcome, {session.user?.name}</p>

      {!address ? (
        <div className="bg-zinc-900 rounded-3xl p-8 mb-10">
          <p className="text-gray-400 mb-4">
            Link your validator address to see your live stats.
          </p>
          <div className="flex gap-3">
            <input
              value={addressInput}
              onChange={(e) => setAddressInput(e.target.value)}
              placeholder="0x..."
              className="flex-1 bg-zinc-800 rounded-xl px-4 py-3 font-mono text-sm outline-none focus:ring-2 focus:ring-cyan-500"
            />
            <button
              onClick={linkAddress}
              className="bg-cyan-500 hover:bg-cyan-400 text-black px-6 py-3 rounded-xl font-semibold"
            >
              Link
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between mb-10 bg-zinc-900 rounded-2xl px-6 py-4">
          <p className="font-mono text-sm text-gray-400">
            {address.slice(0, 8)}…{address.slice(-6)}
          </p>
          <button
            onClick={() => {
              localStorage.removeItem(ADDRESS_KEY);
              setAddress("");
            }}
            className="text-sm text-gray-500 hover:text-red-400"
          >
            Unlink
          </button>
        </div>
      )}

      {address && !stats.live && !loading && (
        <div className="bg-yellow-900/30 border border-yellow-700/50 text-yellow-300 text-sm rounded-2xl px-6 py-4 mb-10">
          Connected to the node for block height and balance, but validator-specific
          stats (blocks proposed, uptime, rewards) need a custom RPC method on
          qc-node that isn&apos;t implemented yet — showing zeros until then.
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-zinc-900 p-8 rounded-3xl">
          <p className="text-gray-400">Current Block</p>
          <p className="text-5xl font-mono mt-3">{stats.blockNumber}</p>
        </div>

        <div className="bg-zinc-900 p-8 rounded-3xl">
          <p className="text-gray-400">Your Balance</p>
          <p className="text-5xl font-mono mt-3">
            {stats.balance.toLocaleString(undefined, { maximumFractionDigits: 2 })} QTC
          </p>
        </div>

        <div className="bg-zinc-900 p-8 rounded-3xl">
          <p className="text-gray-400">Blocks Proposed</p>
          <p className="text-5xl font-mono mt-3">{stats.blocksProposed}</p>
        </div>

        <div className="bg-zinc-900 p-8 rounded-3xl">
          <p className="text-gray-400">Uptime</p>
          <p className="text-5xl font-mono mt-3 text-green-400">{stats.uptime}%</p>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-6">Recent Activity</h2>
        <div className="bg-zinc-900 rounded-3xl p-8 text-gray-400">
          {address
            ? "Live activity feed coming soon — needs a qc-node event/log RPC method."
            : "Link your validator address above to see live data."}
        </div>
      </div>
    </div>
  );
}
