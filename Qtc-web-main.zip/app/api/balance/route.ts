import { NextRequest, NextResponse } from "next/server";
import { getBalance } from "@/lib/rpc";

export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get("address");
  if (!address) {
    return NextResponse.json({ error: "Missing address" }, { status: 400 });
  }
  const balance = await getBalance(address);
  return NextResponse.json({ balance });
}
