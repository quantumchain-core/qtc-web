import { NextResponse } from "next/server";
import { getNetworkStats, getBlockNumber } from "@/lib/rpc";

export async function GET() {
  const [network, blockNumber] = await Promise.all([
    getNetworkStats(),
    getBlockNumber(),
  ]);
  return NextResponse.json({ ...network, blockNumber });
}
