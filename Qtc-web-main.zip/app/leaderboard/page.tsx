import Navbar from "@/components/Navbar";
import Leaderboard from "@/components/Leaderboard";

export default function LeaderboardPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="max-w-5xl mx-auto px-6 pt-32 pb-24">
        <h1 className="text-5xl font-bold mb-10">Validator Leaderboard</h1>
        <Leaderboard />
      </div>
    </main>
  );
}
