import { ShieldCheck, Zap, Globe, Lock } from "lucide-react";

const features = [
  {
    icon: ShieldCheck,
    title: "Post-Quantum Secure",
    desc: "Signature and key-exchange schemes designed to resist attacks from quantum computers.",
  },
  {
    icon: Zap,
    title: "High Throughput",
    desc: "A lean consensus layer built for fast finality without sacrificing decentralization.",
  },
  {
    icon: Globe,
    title: "Open Validator Set",
    desc: "Anyone can run a node and join the validator set — no permissioned gatekeeping.",
  },
  {
    icon: Lock,
    title: "Transparent by Design",
    desc: "Every block, proposer, and reward is verifiable on-chain via open RPC endpoints.",
  },
];

export default function Features() {
  return (
    <section className="py-24 px-6 max-w-6xl mx-auto" id="features">
      <h2 className="text-4xl font-bold text-center mb-16">Why QuantumChain</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="bg-zinc-900 p-8 rounded-3xl">
            <Icon className="text-cyan-400 mb-4" size={32} />
            <h3 className="text-xl font-semibold mb-2">{title}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
