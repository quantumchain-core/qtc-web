"use client";

import { useEffect, useState } from "react";

type ValidatorRow = {
  address: string;
  blocksProposed: number;
  uptime: number;
};

export default function Leaderboard() {
  const [rows, setRows] = useState<ValidatorRow[]>([]);
  const [live, setLive] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/leaderboard")
      .then((r) => r.json())
      .then((data) => {
        setRows(data.validators || []);
        setLive(!!data.live);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="text-gray-500 text-center py-12">Loading leaderboard…</div>;
  }

  if (!live || rows.length === 0) {
    return (
      <div className="bg-zinc-900 rounded-3xl p-8 text-gray-400 text-center">
        Leaderboard data isn&apos;t available yet — qc-node needs a validator
        registry RPC method (e.g. <code>qtc_getValidators</code>) before this
        can show live rankings.
      </div>
    );
  }

  return (
    <div className="bg-zinc-900 rounded-3xl overflow-hidden">
      <table className="w-full text-left">
        <thead className="bg-zinc-800 text-gray-400 text-sm">
          <tr>
            <th className="px-6 py-4">#</th>
            <th className="px-6 py-4">Validator</th>
            <th className="px-6 py-4">Blocks Proposed</th>
            <th className="px-6 py-4">Uptime</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((v, i) => (
            <tr key={v.address} className="border-t border-zinc-800">
              <td className="px-6 py-4 text-gray-500">{i + 1}</td>
              <td className="px-6 py-4 font-mono text-sm">
                {v.address.slice(0, 6)}…{v.address.slice(-4)}
              </td>
              <td className="px-6 py-4">{v.blocksProposed}</td>
              <td className="px-6 py-4 text-green-400">{v.uptime}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
