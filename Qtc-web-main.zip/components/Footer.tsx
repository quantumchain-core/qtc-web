import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-gray-800 py-12 px-6 text-center text-gray-500 text-sm">
      <div className="flex justify-center gap-8 mb-6">
        <Link href="/dashboard" className="hover:text-cyan-400">Dashboard</Link>
        <Link href="/leaderboard" className="hover:text-cyan-400">Leaderboard</Link>
        <a
          href="https://github.com/quantumchain-core/qc-node"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-cyan-400"
        >
          GitHub
        </a>
      </div>
      <p>© {new Date().getFullYear()} QuantumChain. Post-quantum Layer 1.</p>
    </footer>
  );
}
