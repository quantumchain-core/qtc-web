// NOTE: These figures are placeholders. Replace with QuantumChain's actual
// supply/distribution numbers before deploying — don't ship made-up tokenomics.
const allocations = [
  { label: "Validator Rewards", pct: 40 },
  { label: "Community / Ecosystem", pct: 25 },
  { label: "Core Team", pct: 20 },
  { label: "Treasury / Reserve", pct: 15 },
];

export default function Tokenomics() {
  return (
    <section className="py-24 px-6 max-w-4xl mx-auto" id="tokenomics">
      <h2 className="text-4xl font-bold text-center mb-4">Tokenomics</h2>
      <p className="text-gray-500 text-center text-sm mb-16">
        Placeholder figures — update with QTC&apos;s finalized distribution.
      </p>
      <div className="space-y-4">
        {allocations.map(({ label, pct }) => (
          <div key={label}>
            <div className="flex justify-between text-sm mb-2">
              <span>{label}</span>
              <span className="text-cyan-400">{pct}%</span>
            </div>
            <div className="w-full bg-zinc-800 rounded-full h-3">
              <div
                className="bg-cyan-500 h-3 rounded-full"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
