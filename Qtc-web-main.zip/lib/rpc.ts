const RPC_URL = process.env.NEXT_PUBLIC_RPC_URL || "http://localhost:8545";

async function rpcCall(method: string, params: any[] = []) {
  const res = await fetch(RPC_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", method, params, id: 1 }),
    cache: "no-store",
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || "RPC error");
  return data.result;
}

/** Current block height. */
export async function getBlockNumber(): Promise<number> {
  try {
    const result = await rpcCall("eth_blockNumber");
    return parseInt(result, 16) || 0;
  } catch {
    return 0;
  }
}

/** Balance for a given address, in QTC (assumes 18 decimals like ETH). */
export async function getBalance(address: string): Promise<number> {
  try {
    const result = await rpcCall("eth_getBalance", [address, "latest"]);
    const wei = BigInt(result);
    return Number(wei) / 1e18;
  } catch {
    return 0;
  }
}

/**
 * Validator-specific stats (blocks proposed, uptime, rewards).
 * qc-node does not yet expose a custom validator-stats RPC method —
 * this calls a placeholder method name and falls back to zeroed data
 * so the UI never breaks. Swap in the real method once it's added
 * to qc-node (e.g. `qtc_getValidator`).
 */
export async function getValidatorStats(address: string) {
  try {
    const result = await rpcCall("qtc_getValidator", [address]);
    return {
      blocksProposed: result.blocksProposed ?? 0,
      uptime: result.uptime ?? 0,
      rewards: result.rewards ?? 0,
      live: true,
    };
  } catch {
    return { blocksProposed: 0, uptime: 0, rewards: 0, live: false };
  }
}

/**
 * Network-wide stats (validator count, TPS, avg block time).
 * Same caveat as getValidatorStats — placeholder method until
 * qc-node implements it.
 */
export async function getNetworkStats() {
  try {
    const result = await rpcCall("qtc_getNetworkStats");
    return {
      totalValidators: result.totalValidators ?? 0,
      tps: result.tps ?? 0,
      avgBlockTime: result.avgBlockTime ?? 0,
      live: true,
    };
  } catch {
    return { totalValidators: 0, tps: 0, avgBlockTime: 0, live: false };
  }
}

/**
 * Validator leaderboard, sorted by blocks proposed.
 * Placeholder method — falls back to an empty list until qc-node
 * exposes a validator registry.
 */
export async function getLeaderboard() {
  try {
    const result = await rpcCall("qtc_getValidators");
    return { validators: result.validators ?? [], live: true };
  } catch {
    return { validators: [], live: false };
  }
}
